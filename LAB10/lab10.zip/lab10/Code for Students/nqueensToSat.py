
from capstone_tools import minisat_display
from capstone_tools import nSAT_solver_display
from capstone_tools import backtracking_display
from time import time
import os
    


def code(i,j,n):
    return (i-1)*n + j

def decod(m,n):
    if m%n == 0:
        j = n
    else:
        j =m%n
    i = int((m-j)/n) + 1
    return i,j

    
def reduce_nqueens_to_SAT(n):
   #TODO
   
   
   

### Para visualizar las soluciones

def solve_case_backtracking(filename, n, formula):
    start_time = time()        
    backtracking_display(formula, n)
    elapsed_time = time() - start_time   
    print("Elapsed time for test n=%s with backtracking: %0.10f" % (n,elapsed_time)) 
    with open(filename, 'a') as f:
        f.write("%s,backtracking,%s\n" % (n,elapsed_time))

def solve_case_minisat(filename, n, formula):
    start_time = time()        
    minisat_display(formula, n)
    elapsed_time = time() - start_time   
    print("Elapsed time for test n=%s with minisat: %0.10f" % (n,elapsed_time))
    with open(filename, 'a') as f:
        f.write("%s,minisat,%s\n" % (n,elapsed_time))

def solve_case_nSAT_solver(filename, n, formula):
    start_time = time()        
    nSAT_solver_display(formula, n)
    elapsed_time = time() - start_time   
    print("Elapsed time for test n=%s with SATSolver: %0.10f" % (n,elapsed_time))
    with open(filename, 'a') as f:
        f.write("%s,SATSolver,%s\n" % (n,elapsed_time))

def generate_formula(filename, n):
    start_time = time()        
    formula = reduce_nqueens_to_SAT(n)
    elapsed_time = time() - start_time   
    print("Elapsed time for n=%s sized formula generation: %0.10f seconds." % (n,elapsed_time))
    with open(filename, 'a') as f:
        f.write("%s,formula,%s\n" % (n,elapsed_time))
    return formula
        
def test():

    filename = 'myresults/n_queens_times.csv'
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    
   
    formula = generate_formula(filename, 10)
    solve_case_minisat(filename, 10, formula)    
    solve_case_backtracking(filename, 10, formula)
    solve_case_nSAT_solver(filename, 10, formula)
                   
    '''
    formula = generate_formula(filename, 11) 
    solve_case_minisat(filename, 11, formula)
    solve_case_backtracking(filename, 11, formula)
    solve_case_nSAT_solver(filename, 11, formula)
    

    formula = generate_formula(filename, 15)
    solve_case_minisat(filename, 15, formula)
    solve_case_backtracking(filename, 15, formula)
    solve_case_nSAT_solver(filename, 15, formula)
    
    
    formula = generate_formula(filename, 16)
    solve_case_minisat(filename, 16, formula)
    solve_case_backtracking(filename, 16, formula)
    solve_case_nSAT_solver(filename, 16, formula)
    
    
    formula = generate_formula(filename, 28)
    solve_case_minisat(filename, 28, formula)
    solve_case_backtracking(filename, 28, formula)
    
    
    formula = generate_formula(filename, 50)
    solve_case_minisat(filename, 50, formula)
    '''
    
    
    
    

test()
